﻿'use strict';
describe('[%namespace%]', function () {
    beforeEach(module('%namespace%'));
    beforeEach(inject(function ($injector, $q) {
    }));

    describe(' - (Service: %ccClassName%)-', function () {

    });
});