﻿'use strict';
angular.module('%namespace%', [])
.service('$%ccClassName%Service', ['$rootScope',
function ($rootScope) {
    return {

    };
}]);
