﻿'use strict';
angular.module('%namespace%', [])
.factory('$%ccClassName%', [function () {
    var %ccClassName% = {};//function(){}
    
    return %ccClassName%;
}]);