﻿'use strict';
angular.module('%namespace%.directives', [])
.directive('%ccClassName%', [function () {
    return {
        link: function (scope, element, attrs, ngModel) {

        }
    };
}]);