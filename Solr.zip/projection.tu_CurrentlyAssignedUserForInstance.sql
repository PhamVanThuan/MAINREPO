USE EventProjection
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (
				SELECT DISTINCT ta.Name 
				FROM EventProjection.sys.triggers t
				INNER JOIN EventProjection.sys.tables ta ON ta.object_id = t.parent_id
				WHERE ta.Name LIKE '%CurrentlyAssignedUserForInstance%'
			   )


IF OBJECT_ID('projection.tu_CurrentlyAssignedUserForInstance') is null
BEGIN 
	DECLARE @Qry VARCHAR(1024)
	SET @Qry =	'CREATE TRIGGER projection.tu_CurrentlyAssignedUserForInstance ON  projection.CurrentlyAssignedUserForInstance ' +
				'FOR UPDATE ' +
				'AS ' +
				'BEGIN ' +
				'SET NOCOUNT ON; ' +
				'END '

	EXECUTE (@Qry)
END
GO

ALTER TRIGGER projection.tu_CurrentlyAssignedUserForInstance ON  projection.CurrentlyAssignedUserForInstance
FOR UPDATE 
AS 

SET NOCOUNT ON

/*************************************************************************************************************************
		Author		:	VirekR
		CreateDate	:	2016/01/22
		Description	:	Passing the generickey via a temp table and a proc that will 
						determine which queue to add this message to - used for solr index update.
																																											
		
**************************************************************************************************************************/
BEGIN
			/* Lets get the ThirdPartyInvoiceKey and pass it to its respective queue based on the generickeytypekey */			SELECT TOP 0 * INTO #SolrIndexUpdate FROM Process.template.SolrIndexUpdate   					
	INSERT INTO	#SolrIndexUpdate (GenericKey, GenericKeyTypeKey)	SELECT		GenericKey,GenericKeyTypeKey
	FROM			INSERTED i
	WHERE		GenericKeyTypeKey = 54					   
	   	   
	IF (SELECT COUNT(GenericKey) FROM #SolrIndexUpdate) > 0

	   BEGIN		  	
	   /**********************************************************/
    		  EXEC process.solr.pSolrIndexQueueDetermine
	   /**********************************************************/
	   END 
END --END TRIGGER
GO
