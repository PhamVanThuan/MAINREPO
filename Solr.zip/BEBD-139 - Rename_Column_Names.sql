USE [2am]
GO

IF EXISTS (	 SELECT c.* 
			 FROM sys.tables t
			 INNER JOIN sys.schemas s ON s.schema_id = t.schema_id
			 INNER JOIN sys.columns c ON c.object_id = t.object_id
			 WHERE   s.Name = 'solr' 
			 AND	    t.Name = 'Client'
			 AND	    c.Name = 'LegalEntityStatusKey'
		 )   
  EXEC  sp_rename 'solr.Client.LegalEntityStatusKey', 'LegalEntityStatus', 'COLUMN'
ELSE 
    PRINT 'Column already updated'


--  SELECT TOP 1 * FROM [2am].solr.Client

