USE Process

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF OBJECT_ID('solr.pThirdPartyValuerDetail') is null
BEGIN 
	DECLARE @Qry VARCHAR(1024)
	SET @Qry =	'CREATE PROCEDURE solr.pThirdPartyValuerDetail ' +
				'AS ' +
				'BEGIN ' +
				'SET NOCOUNT ON; ' +
				'END '

	EXECUTE (@Qry)
END
GO


ALTER PROCEDURE solr.pThirdPartyValuerDetail @Msg VARCHAR(1024) OUTPUT, @LegalEntityKey INT = NULL
AS

/*************************************************************************************************************************
		Author		:	VirekR
		CreateDate	:	2016/03/18
		Description	:	This proc will:

						1. Return valuer related information used by Solr for indexing purposes 
																																			
		History:
					
			--------------------------------------------------------------------	
	--Helper Code:	
			DECLARE @msg VARCHAR(1024)
			
			/*Optional Parameter of LegalEntityKey, if populated do that one only, if not do all */  		
			EXEC Process.solr.pThirdPartyValuerDetail @msg OUTPUT--,85553
			SELECT @msg
	--------------------------------------------------------------------
**************************************************************************************************************************/
BEGIN
	BEGIN TRY	

	--DECLARE @msg VARCHAR(255)
	--	  ,@LegalEntityKey INT = 474690

	/****************************************************** VALUERS ****************************************************************/
		IF OBJECT_ID('tempdb.dbo.#ValOffer') IS NOT NULL
			DROP TABLE #ValOffer
		
		
		CREATE TABLE #ValOffer (LegalEntityKey INT, OfferKey VARCHAR(20), OfferType VARCHAR(100), AccountKey VARCHAR(20) )

		-- Some ugly if statements to gather some performance benefits
		IF @LegalEntityKey IS NOT NULL
		  BEGIN
		
			 INSERT INTO #ValOffer (LegalEntityKey, OfferKey, OfferType, AccountKey)  
			 SELECT	   DISTINCT le.LegalEntityKey,CAST(o.OfferKey AS VARCHAR(20)) OfferKey, CAST(ot.Description AS VARCHAR(100)) OfferType, CAST(o.ReservedAccountKey AS VARCHAR(20)) AccountKey		
			 FROM	   [2AM].dbo.Valuator vl (NOLOCK)
			 LEFT JOIN   [2AM].dbo.Valuation v	(NOLOCK) ON vl.ValuatorKey = v.ValuatorKey
			 LEFT JOIN   [2am].dbo.LegalEntity le (NOLOCK) ON le.LegalEntityKey = vl.LegalEntityKey
			 LEFT JOIN   [2AM].dbo.OfferMortgageLoan  oml (NOLOCK) ON oml.PropertyKey = v.PropertyKey
			 LEFT JOIN   [2AM].dbo.Offer o	(NOLOCK) ON o.OfferKey = oml.OfferKey
			 LEFT JOIN   [2am].dbo.OfferType ot   (NOLOCK) on ot.OfferTypeKey = o.OfferTypeKey
			 WHERE	   le.LegalEntityKey = @LegalEntityKey 
		  END
		  
		ELSE 
		BEGIN
			 INSERT INTO #ValOffer (LegalEntityKey, OfferKey, OfferType, AccountKey)  
			 SELECT	   DISTINCT le.LegalEntityKey,CAST(o.OfferKey AS VARCHAR(20)) OfferKey, CAST(ot.Description AS VARCHAR(100)) OfferType, CAST(o.ReservedAccountKey AS VARCHAR(20)) AccountKey		
			 FROM	   [2AM].dbo.Valuator vl (NOLOCK)
			 LEFT JOIN   [2AM].dbo.Valuation v	(NOLOCK) ON vl.ValuatorKey = v.ValuatorKey
			 LEFT JOIN   [2am].dbo.LegalEntity le (NOLOCK) ON le.LegalEntityKey = vl.LegalEntityKey
			 LEFT JOIN   [2AM].dbo.OfferMortgageLoan  oml (NOLOCK) ON oml.PropertyKey = v.PropertyKey
			 LEFT JOIN   [2AM].dbo.Offer o	(NOLOCK) ON o.OfferKey = oml.OfferKey
			 LEFT JOIN   [2am].dbo.OfferType ot   (NOLOCK) on ot.OfferTypeKey = o.OfferTypeKey
		END	

		IF (SELECT COUNT(LegalEntityKey) FROM #ValOffer) > 1  
		  CREATE INDEX ix_Val ON #ValOffer (LegalEntityKey);

		--	SELECT * FROM #ValOffer WHERE Legalentitykey = 615700

		-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			-- Flatten Offers + OfferTypes + AccountKeys
		-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		IF OBJECT_ID('tempdb.dbo.#FlatLValOffers') IS NOT NULL
					DROP TABLE #FlatLValOffers
					
		SELECT t.LegalEntityKey,
				 ( SELECT [2AM].[dbo].[SpaceDelimit]( DISTINCT CAST(x.OfferKey AS NVARCHAR(MAX)))
				   FROM #ValOffer x
				   WHERE x.LegalEntityKey = t.LegalEntityKey) as 'Offers',

				 ( SELECT [2AM].[dbo].[SpaceDelimit]( DISTINCT x.OfferType)
				   FROM #ValOffer x
				   WHERE x.LegalEntityKey = t.LegalEntityKey) as 'OfferTypes',

				 ( SELECT [2AM].[dbo].[SpaceDelimit]( DISTINCT CAST(x.AccountKey AS NVARCHAR(MAX)))
				   FROM #ValOffer x
				   WHERE x.LegalEntityKey = t.LegalEntityKey) as 'Accounts'
		INTO	#FlatLValOffers
		FROM	#ValOffer t
		GROUP BY t.LegalEntityKey		

		IF (SELECT COUNT(LegalEntityKey) FROM #FlatLValOffers) > 1
		  CREATE INDEX ix_OfferType ON #FlatLValOffers (LegalEntityKey)

		/********************************************************* MAIN VALUER QUERY *****************************************************************/
		IF OBJECT_ID('tempdb.dbo.#Valuer') IS NOT NULL
					DROP TABLE #Valuer

		SELECT 
				DISTINCT
				le.LegalEntityKey, 
				CASE 
				    WHEN let.LegalEntityTypeKey in (1,2)
						  THEN 'Person'
				    WHEN let.LegalEntityTypeKey in (3,4,5)
						  THEN 'Business'
				END AS 'LegalEntityType',
				'Valuer' AS 'ThirdPartyType',
				'' AS 'ThirdPartySubType',					
				le.RegisteredName AS 'LegalName', 
				ISNULL(le.TradingName, '')		 AS 'TradingName',
				ISNULL(le.RegistrationNumber, '')	 AS 'LegalIdentity',
				ISNULL(le.TaxNumber, '')			 AS 'TaxNumber',
				CAST(ISNULL(let.Description, '')AS VARCHAR) AS 'LegalIdentityType',					
				v.ValuatorContact AS 'Contact', 
				ISNULL(le.WorkPhoneCode,'') + ISNULL(le.WorkPhoneNumber,'')  AS 'WorkPhoneNumber', 
				ISNULL(le.CellPhoneNumber,'') AS 'CellPhoneNumber',
				REPLACE(ISNULL(le.EmailAddress,''),char(34),' ') AS 'EmailAddress', 
				ISNULL(le.FaxCode,'') + ISNULL(le.FaxNumber,'')  AS 'FaxNumber',
				lea.LegalEntityAddressKey,
				lea.AddressKey,				
				CONVERT(VARCHAR(255),'') AS 'Address',
				fo.Offers		  AS 'OfferKey',
				fo.OfferTypes	  AS 'OfferType',
				fo.Accounts	  AS 'AccountKey'
			INTO #Valuer			
			FROM		   [2am].dbo.LegalEntity le (NOLOCK)	
			INNER JOIN   #FlatLValOffers fo on fo.LegalEntityKey = le.LegalEntityKey		
			INNER JOIN   [2am].dbo.LegalEntityType let (NOLOCK) on le.LegalEntityTypeKey = let.LegalEntityTypeKey			
			INNER JOIN   [2am].dbo.Valuator v (NOLOCK) ON v.LegalEntityKey = fo.LegalEntityKey
			LEFT JOIN	   [2am].dbo.LegalEntityAddress lea (NOLOCK) on le.LegalEntityKey = lea.LegalEntityKey
							 AND	lea.GeneralStatusKey = 1
			 
			 --select * from #Valuer
	     ----------------------------------------------------------------------------------------------------------------------------------------------
		-- Update Address	
		UPDATE	#Valuer SET [Address] =  ([2am].[dbo].[fGetFormattedAddressDelimited] (AddressKey, 0))		

		-- Flatten Address
		IF OBJECT_ID('tempdb.dbo.#FlatValuerAddress') IS NOT NULL
					DROP TABLE #FlatValuerAddress

		SELECT t.LegalEntityKey,
				( SELECT [2AM].[dbo].[SpaceDelimit](DISTINCT CAST(x.Address AS NVARCHAR(MAX)))
				  FROM #Valuer x
			       WHERE x.LegalEntityKey = t.LegalEntityKey) as 'Address'
		INTO	#FlatValuerAddress
		FROM	#Valuer t
		GROUP BY t.LegalEntityKey	 


	IF @LegalEntityKey IS NOT NULL 
		BEGIN
			IF OBJECT_ID('[2am].solr.ThirdParty') IS NOT NULL
				BEGIN
					DELETE 
					FROM	  [2AM].solr.ThirdParty
					WHERE  ThirdPartyType = 'Valuer'
					AND	  LegalEntityKey = @LegalEntityKey
				END
		END
		
		ELSE
		/*
		This piece of code will execute when we are NOT passing through a parameter 
		which means clean out the table and reload the full batch.

		If Exists then clean out the table.
		*/
		BEGIN
			IF OBJECT_ID('[2am].solr.ThirdParty') IS NOT NULL
				     DELETE 
					FROM	  [2AM].solr.ThirdParty
					WHERE  ThirdPartyType = 'Valuer'			
		END


		/****************************** INSERT VALUERS INTO THIRD PARTY TABLE *************************************/
		INSERT INTO [2AM].solr.ThirdParty
					   (	   
						  LegalEntityKey,
						  LegalEntityType,
						  ThirdPartyType,
						  ThirdPartySubType,
						  LegalName,
						  TradingName,
						  LegalIdentityType,
						  LegalIdentity,
						  TaxNumber,
						  Contact,
						  WorkPhoneNumber,
						  CellPhoneNumber,
						  EmailAddress,
						  FaxNumber,																								
						  OfferKey,
						  OfferType,
						  AccountKey,
						  [Address],
						  LastModifiedDate										
						)
		  SELECT  DISTINCT		CAST(v.LegalEntityKey AS VARCHAR),
							 LegalEntityType,
							 ThirdPartyType,
							 ThirdPartySubType,
							 LegalName,
							 TradingName,
							 LegalIdentityType,
							 LegalIdentity,
							 TaxNumber,
							 Contact,
							 WorkPhoneNumber,
							 CellPhoneNumber,
							 EmailAddress,
							 FaxNumber,							
							 OfferKey,
							 OfferType,
							 AccountKey,
							 f.[Address],
							 GETDATE()					
		from #Valuer v
		INNER JOIN #FlatValuerAddress f ON f.LegalEntityKey = v.LegalEntityKey
		

END TRY

		BEGIN CATCH

	   
			set @Msg = 'solr.pThirdPartyValuerDetail: ' + ISNULL(ERROR_MESSAGE(), 'Failed!')
			RAISERROR(@Msg,16,1)

			SELECT TOP 0 * INTO #Errors FROM process.template.errors
	
			DELETE FROM #Errors
			INSERT INTO #Errors (ErrorCodeKey, DateOfError, MSG, SeverityTypeKey)
			SELECT (SELECT ErrorCodeKey FROM process.errorhandling.ErrorCode (NOLOCK) WHERE Description LIKE 'Solr Extract Failure'), GETDATE(), @Msg, 1
	
			EXEC process.errorhandling.pLogErrors @Msg OUTPUT
				
		END CATCH
END
GO

PRINT 'solr.pThirdPartyValuerDetail deployed: ' + cast(getdate() as varchar) + ' to server: '+ @@Servername
GO

GRANT EXECUTE ON OBJECT::solr.pThirdPartyValuerDetail TO [Batch];
GRANT EXECUTE ON OBJECT::solr.pThirdPartyValuerDetail TO [ProcessRole];
GRANT EXECUTE ON OBJECT::solr.pThirdPartyValuerDetail TO [AppRole];