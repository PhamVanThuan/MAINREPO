USE [2am]
GO
/****** Object:  Trigger [dbo].[tu_Detail]    Script Date: 2015-05-08 02:42:13 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO
ALTER TRIGGER dbo.tu_Detail ON dbo.Detail
FOR UPDATE 
AS
/*************************************************************************************************************************
		Author		:	??
		CreateDate	:	??
		Description	:	Trigger to insert into the AuditDetail table
																																									
		History:
					2016/01/22	VirekR		Passing the generickey via a temp table and a proc that will determine 
											which queue to add this message to - used for solr index update.				
		
**************************************************************************************************************************/ SET NOCOUNT ON 

BEGIN
	INSERT INTO dbo.AuditDetail (
		AuditAddUpdateDelete,
		[DetailKey],
		[DetailTypeKey],
		[AccountKey],
		[DetailDate],
		[Amount],
		[Description],
		[LinkID],
		[UserID],
		[ChangeDate]
	)
	SELECT
		'U' as AuditAddUpdateDelete,
		[DetailKey],
		[DetailTypeKey],
		[AccountKey],
		[DetailDate],
		[Amount],
		[Description],
		[LinkID],
		[UserID],
		[ChangeDate]
	FROM	INSERTED;

	/* Lets get the LegalEntityKey and pass it to its respective queue based on the generickeytypekey */
	
	SELECT TOP 0 * INTO #SolrIndexUpdate FROM Process.template.SolrIndexUpdate				
	INSERT INTO	#SolrIndexUpdate (GenericKey, GenericKeyTypeKey)	SELECT		t.ThirdPartyKey AS GenericKey,63 AS GenericKeyTypeKey 
     FROM			INSERTED i
     INNER JOIN	[2am].dbo.ForeclosureAttorneyDetailTypeMapping fat (NOLOCK) ON i.DetailTypeKey = fat.DetailTypeKey  
     INNER JOIN	[2am].dbo.ThirdParty t (NOLOCK) ON t.LegalEntityKey = fat.LegalEntityKey
     WHERE		fat.GeneralStatusKey = 1					   
	   	   
	IF (SELECT COUNT(GenericKey) FROM #SolrIndexUpdate) > 0

	   BEGIN		  	
	   /**********************************************************/
    		  EXEC process.solr.pSolrIndexQueueDetermine
	   /**********************************************************/
	   END

END --END TRIGGER
GO