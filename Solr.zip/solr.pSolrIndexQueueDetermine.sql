USE [Process]
GO
/****** Object:  StoredProcedure [solr].[pSolrIndexQueueDetermine]    Script Date: 2014-12-24 11:10:47 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('solr.pSolrIndexQueueDetermine') is null
BEGIN 
	DECLARE @Qry VARCHAR(1024)
	SET @Qry =	'CREATE PROCEDURE solr.pSolrIndexQueueDetermine ' +
				'AS ' +
				'BEGIN ' +
				'SET NOCOUNT ON; ' +
				'END '

	EXECUTE (@Qry)
END
GO

ALTER PROCEDURE solr.pSolrIndexQueueDetermine
AS

/*************************************************************************************************************************
		Author		:	VirekR
		CreateDate	:	2016/01/22
		Description	:	This proc will differentiate which queue the message will go to based on the generic key type
																				
		History:
					
		EXEC process.solr.pSolrIndexQueueDetermine
	**************************************************************************************************************************/

BEGIN
	-- Continue processing when control table value is ON (value = 1)
	IF (SELECT ControlNumeric FROM [2am].dbo.Control (NOLOCK) WHERE   ControlDescription = 'Is Solr Incremental Update Enabled') = 1
	   BEGIN			
		  BEGIN TRANSACTION
		
		   DECLARE	   @Count		INT = 1,					   
					   @Msg			VARCHAR(1024) = ''    		   

		   IF OBJECT_ID('tempdb.dbo.#MessageQueue') IS NOT NULL
			   DROP TABLE #MessageQueue 

		   CREATE TABLE #MessageQueue
					   (
						   ID				INT IDENTITY(1,1),
						   IndexName			VARCHAR(50),					
						   QueueToPopulate		VARCHAR(200),
						   GenericKeyTypeKey	INT					
					   )
	
		   -- Intentionally left these hardcoded as the dynamic query could potentially cause this to fall over  
		   INSERT INTO #MessageQueue (IndexName, GenericKeyTypeKey)
		   SELECT	'thirdparty'			, 63 UNION
		   SELECT	'client'				, 3  UNION
		   SELECT	'task'				, 18 UNION
		   SELECT	'thirdparty_invoice'	, 54			

		   --	SELECT * FROM #MessageQueue

		   CREATE INDEX ix_IndexName ON #MessageQueue(IndexName);

		   /************* MATCH UP THE QUEUE NAME TO THE TABLE *****************************/
			 UPDATE	m
			 SET		QueueToPopulate = t.QueueToPopulate
			 --  SELECT m.*, t.*
			 FROM	#MessageQueue m
			 INNER JOIN (
							 SELECT	m.IndexName, t.Name AS QueueToPopulate
							 FROM	[2am].sys.tables t
							 INNER JOIN [2am].sys.schemas s ON s.schema_id = t.schema_id
							 INNER JOIN #MessageQueue m ON m.IndexName = SUBSTRING(t.Name,6,100)
							 WHERE	s.Name = 'queues'					   
						  )t ON t.IndexName = m.IndexName
	 			  
		
			   WHILE @Count <= (SELECT COUNT(*) FROM #SolrIndexUpdate)
				   BEGIN																
										   								
					   DECLARE @XML XML
					   SELECT  @XML = ( SELECT	 i.GenericKey, i.GenericKeyTypeKey 
									FROM		 #MessageQueue m
									INNER JOIN #SolrIndexUpdate i ON i.GenericKeyTypeKey = m.GenericKeyTypeKey
									WHERE	  i.ID = @Count
									FOR XML PATH ('SolrUpdate')  
								   )					  
					   
					   DECLARE	@QueueToPopulate VARCHAR(200)				
					   SELECT		@QueueToPopulate = m.QueueToPopulate	  
					   FROM		#MessageQueue m
					   INNER JOIN  #SolrIndexUpdate i ON i.GenericKeyTypeKey = m.GenericKeyTypeKey				
					   WHERE		i.ID = @Count


					   -- Pop the message into its respective queue based on the generickeytypekey
					   DECLARE @InsertIntoQueue NVARCHAR(MAX) = '  INSERT INTO [2am].queues.' + @QueueToPopulate +  '(Data) 
														  SELECT Process.dbo.fConvertXMLtoJSON (''' + CAST(@XML AS NVARCHAR(MAX)) + ''')'


					   EXECUTE sp_executesql @InsertIntoQueue;
				
					   /****************************************************** DEBUG ***************************************************************
					  -- CREATE TABLE staging.dbo.InitiateMessageQueue (ID INT IDENTITY(1,1), GenericKey INT, GenericKeyTypeKey INT, GenericXML XML, QueueToPopulate VARCHAR(100), InsertDate DATETIME)
					   
					   INSERT INTO staging.dbo.InitiateMessageQueue (GenericKey,GenericKeyTypeKey,GenericXML, QueueToPopulate, InsertDate)
					   SELECT	 i.GenericKey, i.GenericKeyTypeKey, @XML , m.QueueToPopulate , GETDATE()
					   FROM	 #MessageQueue m
					   INNER JOIN  #SolrIndexUpdate i ON i.GenericKeyTypeKey = m.GenericKeyTypeKey				
					   WHERE	  i.ID = @Count								
					   ***************************************************************************************************************************/				

    					   SELECT @Count = @Count + 1		  

				    END -- END WHILE
				    			   
		   --   SELECT '#SolrIndexUpdate',* FROM #SolrIndexUpdate

		  COMMIT;

		  END -- END IF Statement that checks for control table value

END

GO

PRINT 'solr.pSolrIndexQueueDetermine deployed: ' + cast(getdate() as varchar) + ' to server: '+ @@Servername
GO

GRANT EXECUTE ON OBJECT::solr.pSolrIndexQueueDetermine TO [Batch];
GRANT EXECUTE ON OBJECT::solr.pSolrIndexQueueDetermine TO [ProcessRole];
GRANT EXECUTE ON OBJECT::solr.pSolrIndexQueueDetermine TO [AppRole];
