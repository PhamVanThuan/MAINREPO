USE [2AM]
GO

/****** Object:  Index [IDX_OfferRoleByLEKey]    Script Date: 2016/02/09 03:12:31 PM ******/

IF EXISTS (
			 SELECT ind.Name, t.*
			 FROM sys.indexes ind 
			 INNER JOIN sys.tables t ON ind.object_id = t.object_id 
			 WHERE ind.Name = 'IDX_OfferRoleByLEKey'
			 AND t.Name = 'OfferRole'
		  )
	 DROP INDEX IDX_OfferRoleByLEKey ON dbo.OfferRole

CREATE NONCLUSTERED INDEX [IDX_OfferRoleByLEKey] ON [dbo].[OfferRole]
(
	[OfferRoleTypeKey] ASC
)
INCLUDE ( 	[LegalEntityKey],
	[OfferKey])

GO


