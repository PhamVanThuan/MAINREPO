
/*********************************************************************** 2AM *********************************************************************/

-------------------------------------------------------------------------------------------------------
-- Grant the AppRole access to all application tables in 2am **FULL ACCESS GRANTED HERE** then revoke at the end of this script
-------------------------------------------------------------------------------------------------------
use [2am]
GO
SELECT ROW_NUMBER() OVER(ORDER BY s.Schema_ID DESC) as 'ID', '['+s.Name+']'+'.'+p.TableName as pName
into #TableNames
FROM (	  SELECT DISTINCT QUOTENAME(SCHEMA_NAME(obj.schema_id)) AS [Schema], QUOTENAME(obj.name) TableName, obj.schema_id
		  FROM sys.objects obj
		  LEFT JOIN sys.database_permissions AS perm ON perm.major_id = obj.[object_id]
		  LEFT JOIN sys.database_principals AS usr ON perm.grantee_principal_id = usr.principal_id
		  WHERE obj.Type = 'U'
		  AND perm.major_id IS NULL
	  )p
join 
(
	select Schema_ID, Name 
	from	  sys.schemas
	where  name in ('solr')
) s on s.Schema_ID = p.schema_id


--  SELECT * FROM #TableNames

declare @i int, @query nvarchar(2000), @PName varchar(100), @query1 nvarchar(2000), @query2 nvarchar(2000), @query3 nvarchar(2000), 
			 @query4 nvarchar(2000), @query5 nvarchar(2000), @query6 nvarchar(2000), @query7 nvarchar(2000)
select @i = 1
while @i <= (select count(1) from #TableNames)
Begin
	select @PName=pName from #TableNames where ID=@i
	select @Query = 'grant Select on OBJECT::'+@PName+' to [AppRole]'
	select @Query1 = 'grant Insert on OBJECT::'+@PName+' to [AppRole]'
	select @Query2 = 'grant Update on OBJECT::'+@PName+' to [AppRole]'
	select @Query3 = 'grant Delete on OBJECT::'+@PName+' to [AppRole]'
	select @Query4 = 'grant Select on OBJECT::'+@PName+' to [ProcessRole]'
	select @Query5 = 'grant Insert on OBJECT::'+@PName+' to [ProcessRole]'
	select @Query6 = 'grant Update on OBJECT::'+@PName+' to [ProcessRole]'
	select @Query7 = 'grant Delete on OBJECT::'+@PName+' to [ProcessRole]'

	begin try
		exec sp_executesql @query
		exec sp_executesql @query1
		exec sp_executesql @query2
		exec sp_executesql @query3
		exec sp_executesql @query4
		exec sp_executesql @query5
		exec sp_executesql @query6
		exec sp_executesql @query7
	end try
	begin catch
		select @query, ISNULL(error_message(), ' Failed')
	end catch	
	set @i = @i + 1
End
drop table #TableNames
GO
------------------------------------------------------------------------------------------------------
-- 2AM ProcessRole grant execute on all SP's & Scalar Functions
-- this is because we will still use some of the procs in the DBO schema
------------------------------------------------------------------------------------------------------
use [2am]
GO
SELECT ROW_NUMBER() OVER(ORDER BY s.Schema_ID DESC) as 'ID', s.Name+'.'+ p.TableName as pName
into #ProcNames 
FROM (	  SELECT DISTINCT QUOTENAME(SCHEMA_NAME(obj.schema_id)) AS [Schema], QUOTENAME(obj.name) TableName, obj.schema_id
		  FROM sys.objects obj
		  LEFT JOIN sys.database_permissions AS perm ON perm.major_id = obj.[object_id]
		  LEFT JOIN sys.database_principals AS usr ON perm.grantee_principal_id = usr.principal_id
		  WHERE obj.Type_Desc  IN
		  (
			  'SQL_SCALAR_FUNCTION',
			  'SQL_STORED_PROCEDURE'			  
		  )
		  AND perm.major_id IS NULL
)p
join 
(
	select Schema_ID, Name from sys.schemas
	where name in ('queues') 
) s on s.Schema_ID = p.schema_id

--  SELECT * FROM #ProcNames

declare @i int, @query nvarchar(2000), @query1 nvarchar(2000),  @PName varchar(100)
select @i = 1
while @i <= (select count(1) from #ProcNames)
Begin
	select @PName=pName from #ProcNames where ID=@i
	select @Query = 'grant execute on OBJECT::'+@PName+' to [ProcessRole]'
	select @Query1 = 'grant execute on OBJECT::'+@PName+' to [AppRole]'
	begin try
		exec sp_executesql @query
		exec sp_executesql @query1
	end try
	begin catch
		select @query, ISNULL(error_message(), ' Failed')
	end catch	
	set @i = @i + 1
End

drop table #ProcNames 


------------------------------------------------------------------------------------------------------
-- 2AM AppRole grant select on Table Functions
------------------------------------------------------------------------------------------------------
use [2am]
GO
SELECT ROW_NUMBER() OVER(ORDER BY s.Schema_ID DESC) as 'ID', s.Name+'.'+p.TableName as pName
INTO #ProcNames 
FROM (	  SELECT DISTINCT QUOTENAME(SCHEMA_NAME(obj.schema_id)) AS [Schema], QUOTENAME(obj.name) TableName, obj.schema_id, obj.type_desc
		  FROM sys.objects obj
		  LEFT JOIN sys.database_permissions AS perm ON perm.major_id = obj.[object_id]
		  LEFT JOIN sys.database_principals AS usr ON perm.grantee_principal_id = usr.principal_id
		  WHERE obj.Type IN ('FN', 'FS', 'FT', 'IF', 'TF', 'V', 'AF')
		  AND perm.major_id IS NULL
	  )p
join 
(
	select Schema_ID, Name 
	from	  sys.schemas
	where  name in ('solr', 'backend', 'Report', 'spv', 'dbo')
) s on s.Schema_ID = p.schema_id
WHERE p.Type_Desc  LIKE
(
	'%TABLE_VALUED_FUNCTION%'
)

--  SELECT * FROM #ProcNames

declare @i int, @query nvarchar(2000), @query1 nvarchar(2000), @PName varchar(100)
select @i = 1
while @i <= (select count(1) from #ProcNames)
Begin
	select @PName=pName from #ProcNames where ID=@i
	select @query = 'grant select on OBJECT::'+@PName+' to [ProcessRole]'
	select @query1 = 'grant select on OBJECT::'+@PName+' to [AppRole]'
	begin try
		exec sp_executesql @query
		exec sp_executesql @query1
	end try
	begin catch
		select @query, ISNULL(error_message(), ' Failed')
	end catch	
	set @i = @i + 1
End

drop table #ProcNames 


use [2am]
GO
SELECT ROW_NUMBER() OVER(ORDER BY s.Schema_ID DESC) as 'ID', s.Name+'.'+p.TableName as pName
INTO #ProcNames 
FROM (	  SELECT DISTINCT QUOTENAME(SCHEMA_NAME(obj.schema_id)) AS [Schema], QUOTENAME(obj.name) TableName, obj.schema_id, obj.type_desc
		  FROM sys.objects obj
		  LEFT JOIN sys.database_permissions AS perm ON perm.major_id = obj.[object_id]
		  LEFT JOIN sys.database_principals AS usr ON perm.grantee_principal_id = usr.principal_id
		  WHERE obj.Type IN ('AF')
		  AND perm.major_id IS NULL
	  )p
join 
(
	select Schema_ID, Name 
	from	  sys.schemas
	where  name in ('solr', 'backend', 'Report', 'spv', 'dbo')
) s on s.Schema_ID = p.schema_id

-- SELECT * FROM #ProcNames


declare @i int, @query nvarchar(2000), @query1 nvarchar(2000), @query2 nvarchar(2000), @PName varchar(100)
select @i = 1
while @i <= (select count(1) from #ProcNames)
Begin
	select @PName=pName from #ProcNames where ID=@i
	select @query = 'grant execute on OBJECT::'+@PName+' to [ProcessRole]'
	select @query1 = 'grant execute on OBJECT::'+@PName+' to [AppRole]'
	select @query2 = 'grant execute on OBJECT::'+@PName+' to [public]'
	begin try
		exec sp_executesql @query
		exec sp_executesql @query1
		exec sp_executesql @query2
	end try
	begin catch
		select @query, ISNULL(error_message(), ' Failed')
	end catch	
	set @i = @i + 1
End

drop table #ProcNames 


/******************************************************* PROCESS ***************************************************************/

------------------------------------------------------------------------------------------------------
-- Grant the Batch access to all tables in Process
------------------------------------------------------------------------------------------------------
use [Process]
GO
SELECT ROW_NUMBER() OVER(ORDER BY s.Schema_ID DESC) as 'ID', '['+s.Name+']'+'.'+p.TableName as pName
into #TableNames
FROM (	  SELECT DISTINCT QUOTENAME(SCHEMA_NAME(obj.schema_id)) AS [Schema], QUOTENAME(obj.name) TableName, obj.schema_id
		  FROM sys.objects obj
		  LEFT JOIN sys.database_permissions AS perm ON perm.major_id = obj.[object_id]
		  LEFT JOIN sys.database_principals AS usr ON perm.grantee_principal_id = usr.principal_id
		  WHERE obj.Type = 'U'
		  AND perm.major_id IS NULL
	  )p
join 
(
	select Schema_ID, Name from sys.schemas
	where name in ('template', 'ErrorHandling', 'Monitor', 'solr', 'dbo', 'backend', 'report')
) s on s.Schema_ID = p.schema_id

declare @i int, @query nvarchar(2000), @PName varchar(100), @query1 nvarchar(2000), @query2 nvarchar(2000)
select @i = 1
while @i <= (select count(1) from #TableNames)
Begin
	select @PName=pName from #TableNames where ID=@i
	select @Query = 'grant Select on OBJECT::'+@PName+' to [Batch]'
	select @Query1 = 'grant Select on OBJECT::'+@PName+' to [AppRole]'
	select @Query2 = 'grant Select on OBJECT::'+@PName+' to [ProcessRole]'
	begin try
		exec sp_executesql @query
		exec sp_executesql @query1
		exec sp_executesql @query2	
	end try
	begin catch
		select @query, ISNULL(error_message(), ' Failed')
	end catch	
	set @i = @i + 1
End
drop table #TableNames
GO

------------------------------------------------------------------------------------------------------
-- Process ProcessRole grant execute on all SP's & Scalar Functions
------------------------------------------------------------------------------------------------------
--use Process
--GO
--SELECT ROW_NUMBER() OVER(ORDER BY s.Schema_ID DESC) as 'ID', s.Name+'.'+ p.TableName as pName
--into #ProcNames 
--FROM (  SELECT DISTINCT QUOTENAME(SCHEMA_NAME(obj.schema_id)) AS [Schema], QUOTENAME(obj.name) TableName, obj.schema_id
--	   FROM sys.objects obj
--	   LEFT JOIN sys.database_permissions AS perm ON perm.major_id = obj.[object_id]
--	   LEFT JOIN sys.database_principals AS usr ON perm.grantee_principal_id = usr.principal_id
--	   WHERE obj.Type_Desc  IN
--	   (
--		   'SQL_SCALAR_FUNCTION',
--		   'SQL_STORED_PROCEDURE'		   
--	   )
--	   AND perm.major_id IS NULL
--)p
--join 
--(
--	select Schema_ID, Name from sys.schemas
--	where name in ('backend', 'batch', 'report', 'fin')
--) s on s.Schema_ID = p.schema_id

---- SELECT * FROM #ProcNames

--declare @i int, @query nvarchar(2000), @query1 nvarchar(2000),  @PName varchar(100)
--select @i = 1
--while @i <= (select count(1) from #ProcNames)
--Begin
--	select @PName=pName from #ProcNames where ID=@i
--	select @Query = 'grant execute on OBJECT::'+@PName+' to [ProcessRole]'
--	select @Query1 = 'grant execute on OBJECT::'+@PName+' to [AppRole]'
--	begin try
--		exec sp_executesql @query
--		exec sp_executesql @query1
--	end try
--	begin catch
--		select @query, ISNULL(error_message(), ' Failed')
--	end catch	
--	set @i = @i + 1
--End

--drop table #ProcNames 


------------------------------------------------------------------------------------------------------
-- Process AppRole ProcessRole grant select on Table Functions
------------------------------------------------------------------------------------------------------
use Process
GO
SELECT ROW_NUMBER() OVER(ORDER BY s.Schema_ID DESC) as 'ID', s.Name+'.'+p.TableName as pName
INTO #ProcNames 
FROM (	  SELECT DISTINCT QUOTENAME(SCHEMA_NAME(obj.schema_id)) AS [Schema], QUOTENAME(obj.name) TableName, obj.schema_id, obj.type_desc
		  FROM sys.objects obj
		  LEFT JOIN sys.database_permissions AS perm ON perm.major_id = obj.[object_id]
		  LEFT JOIN sys.database_principals AS usr ON perm.grantee_principal_id = usr.principal_id
		  WHERE obj.Type IN ('FN', 'FS', 'FT', 'IF', 'TF', 'V', 'AF')
		  AND perm.major_id IS NULL
	  )p
join 
(
	select Schema_ID, Name 
	from	  sys.schemas
	--where  name in ('fin', 'report')
) s on s.Schema_ID = p.schema_id
WHERE p.Type_Desc  IN
(
	'SQL_TABLE_VALUED_FUNCTION'
)

declare @i int, @query nvarchar(2000), @query1 nvarchar(2000), @PName varchar(100)
select @i = 1
while @i <= (select count(1) from #ProcNames)
Begin
	select @PName=pName from #ProcNames where ID=@i
	select @query = 'grant select on OBJECT::'+@PName+' to [ProcessRole]'
	select @query1 = 'grant select on OBJECT::'+@PName+' to [AppRole]'
	begin try
		exec sp_executesql @query
		exec sp_executesql @query1
	end try
	begin catch
		select @query, ISNULL(error_message(), ' Failed')
	end catch	
	set @i = @i + 1
End

drop table #ProcNames 



/************ Some that may have been missed *******************/

USE [2am]
GO

grant Insert on OBJECT:: dbo.ThirdParty to [ProcessRole];
grant Update on OBJECT:: dbo.ThirdParty to [ProcessRole];
grant Delete on OBJECT:: dbo.ThirdParty to [ProcessRole];
grant Select on OBJECT:: dbo.ThirdParty to [ProcessRole];

grant Insert on OBJECT:: dbo.ThirdPartyType to [ProcessRole];
grant Update on OBJECT:: dbo.ThirdPartyType to [ProcessRole];
grant Delete on OBJECT:: dbo.ThirdPartyType to [ProcessRole];
grant Select on OBJECT:: dbo.ThirdPartyType to [ProcessRole];

grant Insert on OBJECT:: dbo.ThirdPartyType to AppRole;
grant Update on OBJECT:: dbo.ThirdPartyType to AppRole;
grant Delete on OBJECT:: dbo.ThirdPartyType to AppRole;
grant Select on OBJECT:: dbo.ThirdPartyType to AppRole;

GO


/*
 use [2AM]
 go
 
 SELECT DISTINCT QUOTENAME(SCHEMA_NAME(obj.schema_id)) AS [Schema], QUOTENAME(obj.name) TableName, usr.*
FROM sys.objects obj
JOIN sys.database_permissions AS perm ON perm.major_id = obj.[object_id]
JOIN sys.database_principals AS usr ON perm.grantee_principal_id = usr.principal_id
WHERE obj.Type_Desc IN ('Aggregate_Function')

UNION 
 SELECT DISTINCT QUOTENAME(SCHEMA_NAME(obj.schema_id)) AS [Schema], QUOTENAME(obj.name) TableName, usr.*
FROM sys.objects obj
JOIN sys.database_permissions AS perm ON perm.major_id = obj.[object_id]
JOIN sys.database_principals AS usr ON perm.grantee_principal_id = usr.principal_id
WHERE obj.Type_Desc = 'CLR_TABLE_VALUED_FUNCTION'
AND QUOTENAME(obj.name) = '[CleanContactNumber]'
*/





