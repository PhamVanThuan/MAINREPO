USE [e-work]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--IF NOT EXISTS (
--				SELECT DISTINCT ta.Name 
--				FROM [2am].sys.triggers t
--				INNER JOIN [2am].sys.tables ta ON ta.object_id = t.parent_id
--				WHERE ta.Name LIKE '%eFolder%'
--			   )


IF OBJECT_ID('dbo.tu_eFolder') is null
BEGIN 
	DECLARE @Qry VARCHAR(1024)
	SET @Qry =	'CREATE TRIGGER dbo.tu_eFolder ON  dbo.eFolder ' +
				'FOR UPDATE ' +
				'AS ' +
				'BEGIN ' +
				'SET NOCOUNT ON; ' +
				'END '

	EXECUTE (@Qry)
END
GO

ALTER TRIGGER dbo.tu_eFolder ON  dbo.eFolder
FOR UPDATE 
AS 

SET NOCOUNT ON

/*************************************************************************************************************************
		Author		:	VirekR
		CreateDate	:	2016/01/22
		Description	:	Passing the generickey via a temp table and a proc that will determine 
						which queue to add this message to - used for solr index update.
																																											
		
**************************************************************************************************************************/
BEGIN
			/* Lets get the ThirdPartyInvoiceKey and pass it to its respective queue based on the generickeytypekey */			SELECT TOP 0 * INTO #SolrIndexUpdate FROM Process.template.SolrIndexUpdate   						 	   
	INSERT INTO	#SolrIndexUpdate (GenericKey, GenericKeyTypeKey)	SELECT		tpi.ThirdPartyInvoiceKey AS GenericKey,54 AS GenericKeyTypeKey
     FROM			INSERTED i
     INNER JOIN	[2am].dbo.ThirdPartyInvoice tpi (NOLOCK) ON tpi.AccountKey = COALESCE(i.eFolderName, '''')
     WHERE		i.eMapName = 'LossControl'
     AND			ISNUMERIC(coalesce(i.eFolderName, '''')) = 1  
	   	   
	IF (SELECT COUNT(GenericKey) FROM #SolrIndexUpdate) > 0

	   BEGIN		  	
	   /**********************************************************/
    		  EXEC process.solr.pSolrIndexQueueDetermine
	   /**********************************************************/
	   END 
END --END TRIGGER
GO
