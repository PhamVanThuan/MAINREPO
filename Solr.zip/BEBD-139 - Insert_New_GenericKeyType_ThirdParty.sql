USE [2AM]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*************************************************************************************************************************
		Author		:	VirekR
		CreateDate	:	2016/02/04
		Description	:	Insert new generickeytype for ThirdParty
															
**************************************************************************************************************************/

DECLARE @GenericKeyTypeKey INT = 63

IF EXISTS (SELECT * FROM [2am].dbo.GenericKeyType WHERE GenericKeyTypeKey = @GenericKeyTypeKey AND Description <> 'ThirdParty')
BEGIN 
    
     DECLARE @GenTypeError VARCHAR(1024) = 'GenericKeyTypeKey: ' + CAST(@GenericKeyTypeKey AS VARCHAR) + ' already been used.'

	RAISERROR(@GenTypeError,16,1);
END

IF NOT EXISTS (SELECT * FROM [2am].dbo.GenericKeyType WHERE GenericKeyTypeKey = @GenericKeyTypeKey AND Description = 'ThirdParty')
BEGIN 

	INSERT INTO GenericKeyType (GenericKeyTypeKey, [Description], [TableName], [PrimaryKeyColumn]) 
	VALUES (63, 'ThirdParty', '[2AM].[dbo].[ThirdParty]', 'ThirdPartyKey')

END
GO

PRINT 'BEBD-139 - Insert_New_GenericKeyType_ThirdParty deployed: ' + cast(getdate() as varchar) + ' to server: '+ @@Servername
GO


/*

SELECT TOP 5 * FROM [2am].dbo.GenericKeyType ORDER BY 1 DESC

*/
