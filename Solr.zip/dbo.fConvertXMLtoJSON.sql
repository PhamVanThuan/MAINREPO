USE Process
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF EXISTS	 (
				SELECT  Name 
				FROM	   Process.sys.objects 
				WHERE   Type = 'FN'
				AND	   Name = 'fConvertXMLtoJSON'
			 )
	   DROP FUNCTION dbo.fConvertXMLtoJSON

GO

CREATE FUNCTION dbo.fConvertXMLtoJSON(@XmlData XML)
		  
RETURNS NVARCHAR(MAX)
    
/*
		Author		:	VirekR
		CreateDate	:	2016/02/04
		Description	:	Converts XML to JSON		

*/

AS
BEGIN
  DECLARE @m NVARCHAR(MAX)
  SELECT @m = STUFF
  (
     (SELECT theline FROM
    (SELECT ','+' {'+STUFF
       (
              (SELECT ',"'+COALESCE(b.c.value('local-name(.)', 'NVARCHAR(255)'),'')+'":'+
                      CASE  WHEN b.c.value('count(*)','int')=0 
					   THEN dbo.fJsonEscapeCharacterHandler(b.c.value('text()[1]','NVARCHAR(MAX)'))
					   ELSE dbo.fConvertXMLtoJSON(b.c.query('*'))
                      END
                 FROM x.a.nodes('*') b(c)                                                                
                 FOR XML PATH(''),TYPE).value('(./text())[1]','NVARCHAR(MAX)')
               ,1,1,'')+'}'
          FROM @XmlData.nodes('/*') x(a)
       ) JSON(theLine)
       FOR XML PATH(''),TYPE).value('.','NVARCHAR(MAX)')
      ,1,1,'')
   RETURN @m
END

GO

PRINT 'dbo.fConvertXMLtoJSON deployed: ' + CAST(GETDATE() AS VARCHAR) + ' to server: '+ @@Servername
GO

GRANT EXECUTE ON OBJECT::dbo.fConvertXMLtoJSON TO [Batch];
GRANT EXECUTE ON OBJECT::dbo.fConvertXMLtoJSON TO [ProcessRole];
GRANT EXECUTE ON OBJECT::dbo.fConvertXMLtoJSON TO [AppRole];