USE Process

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF OBJECT_ID('solr.pThirdPartyAttorneyDetail') is null
BEGIN 
	DECLARE @Qry VARCHAR(1024)
	SET @Qry =	'CREATE PROCEDURE solr.pThirdPartyAttorneyDetail ' +
				'AS ' +
				'BEGIN ' +
				'SET NOCOUNT ON; ' +
				'END '

	EXECUTE (@Qry)
END
GO


ALTER PROCEDURE solr.pThirdPartyAttorneyDetail @Msg VARCHAR(1024) OUTPUT, @LegalEntityKey INT = NULL
AS

/*************************************************************************************************************************
		Author		:	VirekR
		CreateDate	:	2016/03/18
		Description	:	This proc will:

						1. Return attorney related information used by Solr for indexing purposes 
																																			
		History:
					
			--------------------------------------------------------------------	
	--Helper Code:	
			DECLARE @msg VARCHAR(1024)
			
			/*Optional Parameter of LegalEntityKey, if populated do that one only, if not do all */  		
			EXEC Process.solr.pThirdPartyAttorneyDetail @msg OUTPUT,1200964
			SELECT @msg
	--------------------------------------------------------------------
**************************************************************************************************************************/
BEGIN
	BEGIN TRY	

	--DECLARE @msg VARCHAR(255)
	--	  ,@LegalEntityKey INT = 1200964

/************************************************************ REGISTRATION ATTORNEYS ******************************************************/
	IF OBJECT_ID('tempdb.dbo.#Offers') IS NOT NULL
			DROP TABLE #Offers
	
	CREATE TABLE #Offers
	(	LegalEntityKey			INT,
		OfferKey				VARCHAR(MAX),
		OfferType				VARCHAR(MAX),
		LegalEntityAddressKey	INT,
		AddressKey			INT,
		LegalEntityTypeKey		INT,
		AttorneyKey			INT,
		AttorneyContact		VARCHAR(500),
		AttorneyLitigationInd	BIT,
		AttorneyRegistrationInd	BIT,		
		DeedsOfficeKey			INT,
		DeedsOfficeName		VARCHAR(500),
		LegalName				VARCHAR(100),
		TradingName			VARCHAR(50),
		LegalIdentity            VARCHAR(25),
		TaxNumber			     VARCHAR(20),
		WorkPhoneNumber		VARCHAR(50),
		CellPhoneNumber		VARCHAR(50),
		EmailAddress		     VARCHAR(50),
		FaxNumber			     VARCHAR(50)
	)

	-- Some ugly if statements to gather some performance benefits
	IF @LegalEntityKey IS NOT NULL
	BEGIN

	    INSERT INTO #Offers (
			LegalEntityKey
		    ,LegalEntityAddressKey
		    ,AddressKey
		    ,OfferKey
		    ,OfferType
		    ,LegalEntityTypeKey
		    ,AttorneyKey
		    ,AttorneyContact
		    ,AttorneyLitigationInd
		    ,AttorneyRegistrationInd
		    ,DeedsOfficeKey
		    ,DeedsOfficeName
		    ,LegalName			
		    ,TradingName			
		    ,LegalIdentity            
		    ,TaxNumber			     
		    ,WorkPhoneNumber		
		    ,CellPhoneNumber		
		    ,EmailAddress		     
		    ,FaxNumber			     
		    )
	    SELECT a.LegalEntityKey
		    ,lea.LegalEntityAddressKey
		    ,lea.AddressKey
		    ,CAST(o.OfferKey	 AS VARCHAR(MAX))
		    ,CAST(ot.Description AS VARCHAR(MAX))
		    ,le.LegalEntityTypeKey
		    ,a.AttorneyKey
		    ,a.AttorneyContact
		    ,a.AttorneyLitigationInd
		    ,a.AttorneyRegistrationInd
		    ,do.DeedsOfficeKey
		    ,do.Description
		    ,le.RegisteredName AS 'LegalName' 
		    ,ISNULL(le.TradingName, '')		AS 'TradingName'
		    ,ISNULL(le.RegistrationNumber, '')	AS 'LegalIdentity'
		    ,ISNULL(le.TaxNumber, '')			AS 'TaxNumber'
		    ,ISNULL(le.WorkPhoneCode,'') + ISNULL(le.WorkPhoneNumber,'')  AS WorkPhoneNumber
		    ,ISNULL(le.CellPhoneNumber,'') AS CellPhoneNumber
		    ,REPLACE(ISNULL(le.EmailAddress,''),char(34),' ') AS EmailAddress
		    ,ISNULL(le.FaxCode,'') + ISNULL(le.FaxNumber,'')  AS FaxNumber
	    FROM [2am].dbo.Attorney a (NOLOCK)
	    INNER JOIN [2am].dbo.DeedsOffice do (NOLOCK) ON a.DeedsOfficeKey = do.DeedsOfficeKey
	    INNER JOIN [2am].dbo.LegalEntity le (NOLOCK) ON le.LegalEntityKey = a.LegalEntityKey
	    LEFT JOIN [2am].dbo.OfferRole orl   (NOLOCK) ON orl.LegalEntityKey = le.LegalEntityKey
									    AND orl.OfferRoleTypeKey = 4
	    LEFT JOIN [2am].dbo.OfferRoleType ort (NOLOCK) ON ort.OfferRoleTypeKey = orl.OfferRoleTypeKey		
	    LEFT JOIN [2am].dbo.Offer o (NOLOCK) ON orl.OfferKey = o.OfferKey
	    LEFT JOIN [2am].dbo.OfferType ot (NOLOCK) ON ot.OfferTypeKey = o.OfferTypeKey
	    LEFT JOIN [2am].dbo.LegalEntityAddress lea (NOLOCK) ON orl.LegalEntityKey = lea.LegalEntityKey
						    AND lea.GeneralStatusKey = 1
	    WHERE	 le.LegalEntityKey = @LegalEntityKey		
	   order by a.LegalEntityKey, o.offerkey 		    	   	      

	   END -- END IF to check for @LegalEntityKey

	   ELSE
	   BEGIN

		 INSERT INTO #Offers (
			LegalEntityKey
		    ,LegalEntityAddressKey
		    ,AddressKey
		    ,OfferKey
		    ,OfferType
		    ,LegalEntityTypeKey
		    ,AttorneyKey
		    ,AttorneyContact
		    ,AttorneyLitigationInd
		    ,AttorneyRegistrationInd
		    ,DeedsOfficeKey
		    ,DeedsOfficeName
		    ,LegalName			
		    ,TradingName			
		    ,LegalIdentity            
		    ,TaxNumber			     
		    ,WorkPhoneNumber		
		    ,CellPhoneNumber		
		    ,EmailAddress		     
		    ,FaxNumber			     
		    )
	    SELECT a.LegalEntityKey
		    ,lea.LegalEntityAddressKey
		    ,lea.AddressKey
		    ,CAST(o.OfferKey	 AS VARCHAR(MAX))
		    ,CAST(ot.Description AS VARCHAR(MAX))
		    ,le.LegalEntityTypeKey
		    ,a.AttorneyKey
		    ,a.AttorneyContact
		    ,a.AttorneyLitigationInd
		    ,a.AttorneyRegistrationInd
		    ,do.DeedsOfficeKey
		    ,do.Description
		    ,le.RegisteredName AS 'LegalName' 
		    ,ISNULL(le.TradingName, '')		AS 'TradingName'
		    ,ISNULL(le.RegistrationNumber, '')	AS 'LegalIdentity'
		    ,ISNULL(le.TaxNumber, '')			AS 'TaxNumber'
		    ,ISNULL(le.WorkPhoneCode,'') + ISNULL(le.WorkPhoneNumber,'')  AS WorkPhoneNumber
		    ,ISNULL(le.CellPhoneNumber,'') AS CellPhoneNumber
		    ,REPLACE(ISNULL(le.EmailAddress,''),char(34),' ') AS EmailAddress
		    ,ISNULL(le.FaxCode,'') + ISNULL(le.FaxNumber,'')  AS FaxNumber
	    FROM [2am].dbo.Attorney a (NOLOCK)
	    INNER JOIN [2am].dbo.DeedsOffice do (NOLOCK) ON a.DeedsOfficeKey = do.DeedsOfficeKey
	    INNER JOIN [2am].dbo.LegalEntity le (NOLOCK) ON le.LegalEntityKey = a.LegalEntityKey
	    LEFT JOIN [2am].dbo.OfferRole orl   (NOLOCK) ON orl.LegalEntityKey = le.LegalEntityKey
									    AND orl.OfferRoleTypeKey = 4
	    LEFT JOIN [2am].dbo.OfferRoleType ort (NOLOCK) ON ort.OfferRoleTypeKey = orl.OfferRoleTypeKey		
	    LEFT JOIN [2am].dbo.Offer o (NOLOCK) ON orl.OfferKey = o.OfferKey
	    LEFT JOIN [2am].dbo.OfferType ot (NOLOCK) ON ot.OfferTypeKey = o.OfferTypeKey
	    LEFT JOIN [2am].dbo.LegalEntityAddress lea (NOLOCK) ON orl.LegalEntityKey = lea.LegalEntityKey
						    AND lea.GeneralStatusKey = 1

	   END --END ELSE for @LegalEntityKey check

	IF (SELECT COUNT(LegalEntityKey) FROM #Offers) > 1
	   CREATE INDEX ix_Offer ON #Offers (LegalEntityKey);
	
	--	SELECT * FROM #Offers WHERE LegalEntityKey = 474641 ORDER BY OfferKey
	
	--	Flatten out the OfferKey and OfferType so it can one a single line and searchable from Solr
	IF OBJECT_ID('tempdb.dbo.#FlatOffers') IS NOT NULL
			DROP TABLE #FlatOffers
	
	SELECT t.LegalEntityKey,		  
		    (SELECT [2AM].[dbo].[SpaceDelimit]( DISTINCT CAST(x.OfferKey AS NVARCHAR(MAX)))
			FROM #Offers x
			WHERE x.LegalEntityKey = t.LegalEntityKey) AS 'Offers',

		  (SELECT [2AM].[dbo].[SpaceDelimit]( DISTINCT CAST(x.OfferType AS NVARCHAR(MAX)))
			FROM #Offers x
			WHERE x.LegalEntityKey = t.LegalEntityKey) AS 'OfferTypes'
			
	INTO	#FlatOffers
	FROM	#Offers t
	GROUP BY t.LegalEntityKey	

	IF (SELECT COUNT(LegalEntityKey) FROM #FlatOffers) > 1
	   CREATE INDEX ix_Offer ON #FlatOffers (LegalEntityKey)

	--	SELECT len(offers) FROM #FlatOffers WHERE LegalEntityKey = 474648 AND Offers LIKE '%999563%'

	----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	-- Main Registration Attorney Select
	-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
	IF OBJECT_ID('tempdb.dbo.#Attorney') IS NOT NULL
			DROP TABLE #Attorney	
	select 
		DISTINCT
					orl.LegalEntityKey, 
					CASE 
						WHEN orl.LegalEntityTypeKey in (1,2)
							THEN 'Person'
						WHEN orl.LegalEntityTypeKey in (3,4,5)
							THEN 'Business'
					END AS 'LegalEntityType',
					'Attorney' AS 'ThirdPartyType',
					CASE	WHEN orl.AttorneyLitigationInd = 1 and orl.AttorneyRegistrationInd = 1
								THEN 'Litigation Attorney Registration Attorney'
							WHEN orl.AttorneyLitigationInd = 1 and orl.AttorneyRegistrationInd = 0
								THEN 'Litigation Attorney'
							WHEN orl.AttorneyLitigationInd = 0 and orl.AttorneyRegistrationInd = 1
								THEN 'Registration Attorney'				
					END AS 'ThirdPartySubType',
					CAST(orl.AttorneyKey AS VARCHAR) AS 'AttorneyKey', 					
					CASE	WHEN orl.LegalEntityTypeKey IN (1,2)
							THEN 'Person'
							ELSE 'Business'
					END AS 'LegalIdentityType',
					CAST(orl.DeedsOfficeKey AS VARCHAR) AS 'DeedsOfficeKey', 
					orl.DeedsOfficeName, 
					orl.AttorneyContact AS 'AttorneyContact', 					
					orl.LegalEntityAddressKey,
					orl.AddressKey,
					CONVERT(VARCHAR(255),'') AS 'Address',
					fo.Offers AS 'OfferKey',
					fo.OfferTypes AS 'OfferType',
					orl.LegalName,
					orl.TradingName,
					orl.LegalIdentity,
					orl.TaxNumber,
					orl.WorkPhoneNumber,
					orl.CellPhoneNumber,
					orl.EmailAddress,
					orl.FaxNumber
	INTO #Attorney			
	FROM #Offers orl
	INNER JOIN (	SELECT MAX(ISNULL(OfferKey,0)) OfferKey, LegalEntityKey 
					FROM #Offers 
					GROUP BY LegalEntityKey 
				)maxO ON maxO.LegalEntityKey = orl.LegalEntityKey 
						AND ISNULL(maxO.OfferKey,0) = ISNULL(orl.OfferKey,0)	
	INNER JOIN #FlatOffers fo on fo.LegalEntityKey = orl.LegalEntityKey					

	--	SELECT LegalEntityAddressKey, * FROM #Attorney  WHERE LegalEntityKey = 1144724 AND OfferKey LIKE '%999563%'

	-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	-- Update Address	
	UPDATE	#Attorney SET [Address] =  ([2am].[dbo].[fGetFormattedAddressDelimited] (AddressKey, 0))		
	
/************************************************************************** LITIGATION ATTORNEYS ***************************************************************************/

		IF OBJECT_ID('tempdb.dbo.#LitigationAccounts') IS NOT NULL
			DROP TABLE #LitigationAccounts
					
		CREATE TABLE #LitigationAccounts (LegalEntityKey INT, AccountKey VARCHAR(200))
		
		IF @LegalEntityKey IS NOT NULL
		BEGIN  

		    INSERT INTO #LitigationAccounts (LegalEntityKey, AccountKey)
		    SELECT	DISTINCT fat.LegalEntityKey, CAST(d.AccountKey AS VARCHAR) AS 'AccountKey'
		    FROM		 [2am].dbo.ForeclosureAttorneyDetailTypeMapping fat (NOLOCK)		
		    INNER JOIN [2AM].dbo.Attorney a (NOLOCK) ON a.LegalEntityKey = fat.LegalEntityKey		
		    LEFT JOIN  [2AM].dbo.Detail d	(NOLOCK) ON d.DetailTypeKey = fat.DetailTypeKey		
		    WHERE	 fat.GeneralStatusKey = 1
		    AND  	 fat.LegalEntityKey = @LegalEntityKey

		END -- END IF to check for @LegalEntityKey

		ELSE
		BEGIN
		    INSERT INTO #LitigationAccounts (LegalEntityKey, AccountKey)
		    SELECT	DISTINCT fat.LegalEntityKey, CAST(d.AccountKey AS VARCHAR) AS 'AccountKey'
		    FROM		 [2am].dbo.ForeclosureAttorneyDetailTypeMapping fat (NOLOCK)		
		    INNER JOIN [2AM].dbo.Attorney a (NOLOCK) ON a.LegalEntityKey = fat.LegalEntityKey		
		    LEFT JOIN  [2AM].dbo.Detail d	(NOLOCK) ON d.DetailTypeKey = fat.DetailTypeKey		
		    WHERE	 fat.GeneralStatusKey = 1	 	 
		  
		END -- END ELSE to check for @LegalEntityKey

		--	SELECT distinct accountkey FROM #LitigationAccounts WHERE LegalEntityKey = 1144724 ORDER BY AccountKey
		
		-- Flatten Accounts related to Litigation Attorneys
		IF OBJECT_ID('tempdb.dbo.#FlatLitigationAccounts') IS NOT NULL
			DROP TABLE #FlatLitigationAccounts

		SELECT t.LegalEntityKey,
			   ( SELECT [2AM].[dbo].[SpaceDelimit]( DISTINCT CAST( x.AccountKey AS NVARCHAR(MAX)))
				FROM #LitigationAccounts x
				WHERE x.LegalEntityKey = t.LegalEntityKey) as 'Accounts'
		INTO	 #FlatLitigationAccounts
		FROM	 #LitigationAccounts t
		GROUP BY t.LegalEntityKey		

		IF (SELECT COUNT(LegalEntityKey) FROM #FlatLitigationAccounts) > 1
		  CREATE INDEX ix_Offer ON #FlatLitigationAccounts (LegalEntityKey)
		
		-- SELECT * FROM #FlatLitigationAccounts
		-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		-- Main Litigation Attorney Select

		IF OBJECT_ID('tempdb.dbo.#LitAttorney') IS NOT NULL
			DROP TABLE #LitAttorney

		SELECT DISTINCT   le.LegalEntityKey, 
					   CASE 
						  WHEN let.LegalEntityTypeKey in (1,2)
							 THEN 'Person'
						  WHEN let.LegalEntityTypeKey in (3,4,5)
							 THEN 'Business'
					   END AS 'LegalEntityType',
				'Attorney' AS 'ThirdPartyType',
				CASE	WHEN a.AttorneyLitigationInd = 1 and a.AttorneyRegistrationInd = 1
								THEN 'Litigation Attorney Registration Attorney'
							WHEN a.AttorneyLitigationInd = 1 and a.AttorneyRegistrationInd = 0
								THEN 'Litigation Attorney'
							WHEN a.AttorneyLitigationInd = 0 and a.AttorneyRegistrationInd = 1
								THEN 'Registration Attorney'				
					END AS 'ThirdPartySubType',
				CAST(a.AttorneyKey AS VARCHAR) AS 'AttorneyKey', 
				le.RegisteredName AS 'LegalName', 
				ISNULL(le.TradingName, '')		 AS 'TradingName',
				ISNULL(le.RegistrationNumber, '')	 AS 'LegalIdentity',
				ISNULL(le.TaxNumber, '')			 AS 'TaxNumber',
				CASE	WHEN let.LegalEntityTypeKey IN (1,2)
							THEN 'Person'
						ELSE 'Business'
					END AS 'LegalIdentityType',
				CAST(a.DeedsOfficeKey AS VARCHAR) AS 'DeedsOfficeKey', 
				do.Description		AS 'DeedsOfficeName', 
				a.AttorneyContact	AS 'AttorneyContact', 
				ISNULL(le.WorkPhoneCode,'') + ISNULL(le.WorkPhoneNumber,'')  AS 'WorkPhoneNumber', 
				ISNULL(le.CellPhoneNumber,'') AS 'CellPhoneNumber', 
				REPLACE(ISNULL(le.EmailAddress,''),char(34),' ') AS 'EmailAddress', 
				ISNULL(le.FaxCode,'') + ISNULL(le.FaxNumber,'')  AS 'FaxNumber',
				lea.LegalEntityAddressKey,
				lea.AddressKey,
				CONVERT(VARCHAR(255),'') AS 'Address',				
				fl.Accounts AS 'AccountKeys'		
		INTO	#LitAttorney		 	
		FROM		 [2am].dbo.ForeclosureAttorneyDetailTypeMapping fat (NOLOCK)
		INNER JOIN [2AM].dbo.LegalEntity le (NOLOCK) ON le.LegalEntityKey = fat.LegalEntityKey
		INNER JOIN [2AM].dbo.LegalEntityType let (NOLOCK) on le.LegalEntityTypeKey = let.LegalEntityTypeKey
		INNER JOIN [2AM].dbo.Attorney a (NOLOCK) on le.LegalEntityKey = a.LegalEntityKey
		INNER JOIN #FlatLitigationAccounts fl ON fl.LegalEntityKey = le.LegalEntityKey
		INNER JOIN [2AM].dbo.DeedsOffice do (NOLOCK) on a.DeedsOfficeKey = do.DeedsOfficeKey
		LEFT JOIN	 [2AM].dbo.LegalEntityAddress lea (NOLOCK) on le.LegalEntityKey = lea.LegalEntityKey		
											AND lea.GeneralStatusKey = 1
		WHERE	fat.GeneralStatusKey = 1

		--	SELECT * FROM #LitAttorney WHERE LegalEntityKey = 474648 AND AccountKeys LIKE '%3580240%'
		
		-- Update Address	
		UPDATE	#LitAttorney SET [Address] =  ([2am].[dbo].[fGetFormattedAddressDelimited] (AddressKey, 0))		


		------------------------- FLATTEN OUT THE ADDRESS/ADDRESSES FOR ALL ATTORNEYS ------------------------- 

			IF OBJECT_ID('tempdb.dbo.#FlatAddress') IS NOT NULL
					DROP TABLE #FlatAddress

			;WITH Addresses (LegalEntityKey, Address)
			AS (
					SELECT LegalEntityKey, Address	FROM #Attorney					
					UNION 
					SELECT LegalEntityKey, Address	FROM #LitAttorney					
			)

				SELECT   t.LegalEntityKey,
					    ( SELECT [2AM].[dbo].[SpaceDelimit]( DISTINCT CAST(x.Address AS NVARCHAR(MAX)))
					      FROM Addresses x
					      WHERE x.LegalEntityKey = t.LegalEntityKey) as 'Address'
				INTO	    #FlatAddress
				FROM	    Addresses t
				GROUP BY t.LegalEntityKey
				

				IF (SELECT COUNT(LegalEntityKey) FROM #FlatAddress) > 1
				    CREATE INDEX ix_Offer ON #FlatAddress (LegalEntityKey)	

				--	SELECT * FROM #FlatLitAddress where legalentitykey = 474644
		 
		IF @LegalEntityKey IS NOT NULL 
		BEGIN
			IF OBJECT_ID('[2am].solr.ThirdParty') IS NOT NULL
				BEGIN
					DELETE 
					FROM	  [2AM].solr.ThirdParty
					WHERE  ThirdPartyType = 'Attorney'
					AND	  LegalEntityKey = @LegalEntityKey
				END
		END
		
		ELSE
		/*
		This piece of code will execute when we are NOT passing through a parameter 
		which means clean out the table and reload the full batch.

		If Exists then clean out the table.
		*/
		BEGIN
			IF OBJECT_ID('[2am].solr.ThirdParty') IS NOT NULL
				     DELETE 
					FROM	  [2AM].solr.ThirdParty
					WHERE  ThirdPartyType = 'Attorney'			
		END

		/****************************** INSERT BOTH LITIGATION + CONVEYANCE ATTORNEYS INTO THIRD PARTY TABLE *********************************/
		
		IF OBJECT_ID('tempdb.dbo.#RegAttorneyList') IS NOT NULL
					DROP TABLE #RegAttorneyList
		
		SELECT DISTINCT	CAST(a.LegalEntityKey AS VARCHAR) AS LegalEntityKey,a.LegalEntityType,a.ThirdPartyType,a.ThirdPartySubType, a.LegalName,a.TradingName,a.LegalIdentityType,a.LegalIdentity,a.TaxNumber,a.AttorneyContact,a.WorkPhoneNumber,a.CellPhoneNumber,a.EmailAddress,a.FaxNumber, GETDATE() AS ModifiedDate
						,a.OfferKey, a.OfferType, fa.Address			
		INTO		#RegAttorneyList
		FROM		#Attorney a 
		INNER JOIN	#FlatAddress fa ON fa.LegalEntityKey = a.LegalEntityKey		
		WHERE		a.LegalEntityKey NOT IN (SELECT DISTINCT LegalEntityKey FROM #LitAttorney)
			
		INSERT INTO [2AM].solr.ThirdParty(	   LegalEntityKey,
									   LegalEntityType,
									   ThirdPartyType,
									   ThirdPartySubType,
									   LegalName,
									   TradingName,
									   LegalIdentityType,
									   LegalIdentity,
									   TaxNumber,
									   Contact,
									   WorkPhoneNumber,
									   CellPhoneNumber,
									   EmailAddress,
									   FaxNumber,
									   LastModifiedDate,
									   OfferKey,
									   OfferType,
									   [Address]																									
								    )
		SELECT *
		FROM #RegAttorneyList
		
		-- Insert Attorneys that are not already inserted above
		INSERT INTO [2AM].solr.ThirdParty(	   LegalEntityKey,
									   LegalEntityType,
									   ThirdPartyType,
									   ThirdPartySubType,
									   LegalName,
									   TradingName,
									   LegalIdentityType,
									   LegalIdentity,
									   TaxNumber,
									   Contact,
									   WorkPhoneNumber,
									   CellPhoneNumber,
									   EmailAddress,
									   FaxNumber,
									   LastModifiedDate,
									   AccountKey,
									   [Address]													
									)

		SELECT		DISTINCT CAST(l.LegalEntityKey AS VARCHAR),l.LegalEntityType,l.ThirdPartyType,l.ThirdPartySubType, l.LegalName,l.TradingName,l.LegalIdentityType,l.LegalIdentity,l.TaxNumber,
					l.AttorneyContact,l.WorkPhoneNumber,l.CellPhoneNumber,l.EmailAddress,l.FaxNumber, GETDATE()
					,l.AccountKeys, fa.Address
		FROM		    #LitAttorney l
		INNER JOIN    #FlatAddress fa ON fa.LegalEntityKey = l.LegalEntityKey			
		WHERE		l.LegalEntityKey NOT IN (SELECT DISTINCT LegalEntityKey FROM #RegAttorneyList)
		

END TRY

		BEGIN CATCH

	   
			set @Msg = 'solr.pThirdPartyAttorneyDetail: ' + ISNULL(ERROR_MESSAGE(), 'Failed!')
			RAISERROR(@Msg,16,1)

			SELECT TOP 0 * INTO #Errors FROM process.template.errors
	
			DELETE FROM #Errors
			INSERT INTO #Errors (ErrorCodeKey, DateOfError, MSG, SeverityTypeKey)
			SELECT (SELECT ErrorCodeKey FROM process.errorhandling.ErrorCode (NOLOCK) WHERE Description LIKE 'Solr Extract Failure'), GETDATE(), @Msg, 1
	
			EXEC process.errorhandling.pLogErrors @Msg OUTPUT
				
		END CATCH
END
GO

PRINT 'solr.pThirdPartyAttorneyDetail deployed: ' + cast(getdate() as varchar) + ' to server: '+ @@Servername
GO

GRANT EXECUTE ON OBJECT::solr.pThirdPartyAttorneyDetail TO [Batch];
GRANT EXECUTE ON OBJECT::solr.pThirdPartyAttorneyDetail TO [ProcessRole];
GRANT EXECUTE ON OBJECT::solr.pThirdPartyAttorneyDetail TO [AppRole];