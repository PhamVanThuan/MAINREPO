USE [Process]
GO
/****** Object:  StoredProcedure [solr].[pExecuteSolrImportActiveWorkFlowCases]    Script Date: 2014-12-24 11:10:47 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('solr.pExecuteSolrImportActiveWorkFlowCases') is null
BEGIN 
	DECLARE @Qry VARCHAR(1024)
	SET @Qry =	'CREATE PROCEDURE solr.pExecuteSolrImportActiveWorkFlowCases ' +
				'AS ' +
				'BEGIN ' +
				'SET NOCOUNT ON; ' +
				'END '

	EXECUTE (@Qry)
END
GO

ALTER PROCEDURE solr.pExecuteSolrImportActiveWorkFlowCases @Msg VARCHAR(1024) OUTPUT
AS

/*************************************************************************************************************************
		Author		:	VirekR
		CreateDate	:	2015/10/22
		Description	:	This proc will:
										1.	This proc is for Task index specifically as this will be called after a map
											deploy and only import active cases
										2.	Kick off the datasets required for the Task index for active cases only
										3.	Rebuild the Index
										4.	Make a call to Solr directly to perform import for active cases only
																					
																				
		History:
				2016/02/18  VirekR	    Replaced call to CLR Web Request with just a call directly to Solr to perform update
					
	--------------------------------------------------------------------	
	--Helper Code:	
			DECLARE @Msg VARCHAR(1024)			
			EXEC Process.solr.pExecuteSolrImportActiveWorkFlowCases @Msg OUTPUT
			SELECT @Msg
	--------------------------------------------------------------------
	**************************************************************************************************************************/

BEGIN
	BEGIN TRY
			DECLARE   @InstanceID		    INT
				    ,@RefreshActiveCasesOnly BIT = 1 --Pass through a 1 for active cases only, leave as NULL for all
				    ,@Update			    VARCHAR(500)				    
					--,@Msg VARCHAR(1024)
				
			/******************* EXECUTE THE PROC WHICH WILL POPULATE THE SOLR TABLES **********************/
					EXEC Process.solr.pTaskExtract @Msg OUTPUT, @InstanceID, @RefreshActiveCasesOnly
			/***********************************************************************************************/
		
			-- Rebuild the index
			ALTER INDEX ALL ON [2am].solr.Task REBUILD
			
			
			-- Call the web request to perform an import
			SET @Update = 'powershell.exe Invoke-WebRequest -Uri http://sahl-solr01:8983/solr/Task/dataimport?command=full-import&clean=true&optimize=true'
		  
			EXEC master..xp_cmdshell @Update
									
	END TRY

		BEGIN CATCH
	
			SET @Msg = 'solr.pExecuteSolrImportActiveWorkFlowCases: ' + ISNULL(ERROR_MESSAGE(), 'Failed!')
				RAISERROR(@Msg,16,1)

			SELECT TOP 0 * INTO #Errors FROM process.template.errors
	
			DELETE FROM #Errors
			INSERT INTO #Errors (ErrorCodeKey, DateOfError, MSG, SeverityTypeKey)
			SELECT (SELECT ErrorCodeKey FROM process.errorhandling.ErrorCode (NOLOCK) WHERE Description LIKE 'Solr Extract Failure'), GETDATE(), @Msg, 1
	
			EXEC process.errorhandling.pLogErrors @Msg OUTPUT
				
		END CATCH


		/*
		--Helper Code:	

			DECLARE @Msg VARCHAR(1024)			
			EXEC Process.solr.pExecuteSolrImportActiveWorkFlowCases @Msg OUTPUT
			SELECT @Msg
		*/
END
GO

PRINT 'solr.pExecuteSolrImportActiveWorkFlowCases deployed: ' + cast(getdate() as varchar) + ' to server: '+ @@Servername
GO

GRANT EXECUTE ON OBJECT::solr.pExecuteSolrImportActiveWorkFlowCases TO [Batch];
GRANT EXECUTE ON OBJECT::solr.pExecuteSolrImportActiveWorkFlowCases TO [ProcessRole];
GRANT EXECUTE ON OBJECT::solr.pExecuteSolrImportActiveWorkFlowCases TO [AppRole];
