USE [2am]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--IF NOT EXISTS (
--				SELECT DISTINCT ta.Name 
--				FROM [2am].sys.triggers t
--				INNER JOIN [2am].sys.tables ta ON ta.object_id = t.parent_id
--				WHERE ta.Name LIKE '%Valuator%'
--			   )


IF OBJECT_ID('dbo.ti_Valuator') is null
BEGIN 
	DECLARE @Qry VARCHAR(1024)
	SET @Qry =	'CREATE TRIGGER dbo.ti_Valuator ON  dbo.Valuator ' +
				'FOR INSERT ' +
				'AS ' +
				'BEGIN ' +
				'SET NOCOUNT ON; ' +
				'END '

	EXECUTE (@Qry)
END
GO

ALTER TRIGGER dbo.ti_Valuator ON  dbo.Valuator
FOR INSERT 
AS 

SET NOCOUNT ON

/*************************************************************************************************************************
		Author		:	VirekR
		CreateDate	:	2016/01/22
		Description	:	Passing the generickey via a temp table and a proc that will determine which queue to add this
						message to - used for solr index update.
																																											
		
**************************************************************************************************************************/
BEGIN
			/* Lets get the ThirdPartyKey and pass it to its respective queue based on the generickeytypekey */			SELECT TOP 0 * INTO #SolrIndexUpdate FROM Process.template.SolrIndexUpdate				INSERT INTO	#SolrIndexUpdate (GenericKey, GenericKeyTypeKey)	SELECT		t.ThirdPartyKey AS GenericKey,63 AS GenericKeyTypeKey 
     FROM			INSERTED i
     INNER JOIN	[2am].dbo.ThirdParty t (NOLOCK) ON t.LegalEntityKey = i.LegalEntityKey					   
	   	   
	IF (SELECT COUNT(GenericKey) FROM #SolrIndexUpdate) > 0

	   BEGIN		  	
	   /**********************************************************/
    		  EXEC process.solr.pSolrIndexQueueDetermine
	   /**********************************************************/
	   END 
END --END TRIGGER
GO
