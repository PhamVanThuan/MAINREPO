 /* 
    This step will handle the following: 
    
    1. For each index, call its respective proc which will update the dataset 
    2. Make a call to Solr to import the entire dataset from the solr tables
    3. Optimise the indexes on Solr 
    4. Rebuild indexes on the tables that have non clustered indexes 
    
    Tables and procs can be found on the solr schema in 2am and process db's respectively

    HVAF-546
    */ 

IF (SELECT ControlNumeric FROM [2am].dbo.Control (NOLOCK) WHERE   ControlDescription = 'Is Solr Full Import Enabled') = 1
    BEGIN			 
	   DECLARE @Msg VARCHAR(1024) 
	   EXEC Process.solr.pExecuteSolrFullImport @Msg OUTPUT 
	   SELECT @Msg 
    END
ELSE
    PRINT 'Control table value for Solr Full Import set to 0 (false)'