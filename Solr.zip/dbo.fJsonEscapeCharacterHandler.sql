USE Process
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF EXISTS	 (
				SELECT  Name 
				FROM	   Process.sys.objects 
				WHERE   Type = 'FN'
				AND	   Name = 'fJsonEscapeCharacterHandler'
			 )
	   DROP FUNCTION dbo.fJsonEscapeCharacterHandler

GO

CREATE FUNCTION dbo.fJsonEscapeCharacterHandler (@value NVARCHAR(MAX))
    RETURNS NVARCHAR(MAX)

    /*
		Author		:	VirekR
		CreateDate	:	2016/02/04
		Description	:	This function is used to handle escape characters

    */
AS 

BEGIN
 
 IF (@value is null) RETURN 'null'
 IF (TRY_PARSE( @value AS FLOAT) is not null) RETURN @value

 SET @value=replace(@value,'\','\\')
 SET @value=replace(@value,'"','\"')

 RETURN '"'+@value+'"'
END

GO

PRINT 'dbo.fJsonEscapeCharacterHandler deployed: ' + CAST(GETDATE() AS VARCHAR) + ' to server: '+ @@Servername
GO

GRANT EXECUTE ON OBJECT::dbo.fJsonEscapeCharacterHandler TO [Batch];
GRANT EXECUTE ON OBJECT::dbo.fJsonEscapeCharacterHandler TO [ProcessRole];
GRANT EXECUTE ON OBJECT::dbo.fJsonEscapeCharacterHandler TO [AppRole];

