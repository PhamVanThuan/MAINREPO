USE X2
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('X2.tu_WorkList') is null
BEGIN 
	DECLARE @Qry VARCHAR(1024)
	SET @Qry =	'CREATE TRIGGER X2.tu_WorkList ON  X2.WorkList ' +
				'FOR UPDATE ' +
				'AS ' +
				'BEGIN ' +
				'SET NOCOUNT ON; ' +
				'END '

	EXECUTE (@Qry)
END
GO

ALTER TRIGGER X2.tu_WorkList ON  X2.WorkList
  FOR UPDATE

AS 

/*************************************************************************************************************************
		Author		:	VirekR
		CreateDate	:	2016/01/22
		Description	:	Passing the generickey via a temp table and a proc that will 
						determine which queue to add this message to - used for solr index update
																																														
		
**************************************************************************************************************************/
	SET NOCOUNT ON;

BEGIN	
	
	/* Lets get the InstanceID and pass it to its respective queue based on the generickeytypekey */
			
	SELECT TOP 0 * INTO #SolrIndexUpdate FROM Process.template.SolrIndexUpdate			
		
	INSERT INTO	#SolrIndexUpdate (GenericKey, GenericKeyTypeKey)	SELECT		i.InstanceID AS GenericKey,18 AS GenericKeyTypeKey 
	FROM			INSERTED i  				   
	   	   
	IF (SELECT COUNT(GenericKey) FROM #SolrIndexUpdate) > 0

	   BEGIN		  	
	   /**********************************************************/
    		  EXEC process.solr.pSolrIndexQueueDetermine
	   /**********************************************************/
	   END

END --END TRIGGER
GO
