USE [2am]
GO

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE Name = 'queues')
	BEGIN
		EXEC ('CREATE SCHEMA queues')
	END
GO
