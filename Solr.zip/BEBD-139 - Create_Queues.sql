USE [2am]
GO

-- This will create all the service broker queue tables

EXEC [2am].queues.pCreateServiceBrokerQueue 'solr_client'
GO	 
EXEC [2am].queues.pCreateServiceBrokerQueue 'solr_task'	 
GO
EXEC [2am].queues.pCreateServiceBrokerQueue 'solr_thirdparty'	 
GO
EXEC [2am].queues.pCreateServiceBrokerQueue 'solr_thirdparty_invoice'	 


-- SELECT TOP 1 * FROM [2am].queues.solr_client
-- SELECT TOP 1 * FROM [2am].queues.solr_task
-- SELECT TOP 1 * FROM [2am].queues.solr_thirdparty
-- SELECT TOP 1 * FROM [2am].queues.solr_thirdparty_invoice