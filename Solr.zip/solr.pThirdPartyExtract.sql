USE [Process]
GO
/****** Object:  StoredProcedure [solr].[pThirdPartyExtract]    Script Date: 2016-02-05 03:19:28 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [solr].[pThirdPartyExtract] @Msg VARCHAR(1024) OUTPUT, @ThirdPartyKey INT = NULL 
AS

/*************************************************************************************************************************
		Author		:	DeanA/ VirekR
		CreateDate	:	2014/12/04
		Description	:	This proc will:

						1. Return conveyance and litigation attorney information
						2. Updated to remove GeneralStatusKey = 1 (eWorks uses 2 for active attorneys!!)
						3. Return list of Valuers
						4. Populate [2am].solr.ThirdParty table together with any related accounts / offers attached to them 
															
																				
		History:
				2016/02/08  VirekR	    Change input parameter to be ThirdPartyKey instead of LegalEntityKey
								    Now calling child proc for each ThirdPartyType
					
	--------------------------------------------------------------------	
	--Helper Code:	
			DECLARE @msg VARCHAR(1024)
			/*Optional Parameter of LegalEntityKey, if populated do that one only, if not do all */  
			EXEC Process.solr.pThirdPartyExtract @msg OUTPUT--,1022751
			SELECT @msg
	--------------------------------------------------------------------
**************************************************************************************************************************/
BEGIN
	BEGIN TRY
	   	--DECLARE @msg VARCHAR(255)
		--,@ThirdPartyKey INT --= 5	
	
	    DECLARE  @LegalEntityKey INT
			 , @ThirdPartyTypeKey INT;
	
	    SELECT	@LegalEntityKey	= LegalEntityKey,
				@ThirdPartyTypeKey	= ThirdPartyTypeKey			 
	    FROM	  [2am].dbo.ThirdParty tp (NOLOCK)
	    WHERE   ThirdPartyKey = @ThirdPartyKey;
	    
	    IF @ThirdPartyTypeKey = 1
		  EXEC process.solr.pThirdPartyAttorneyDetail  @Msg OUTPUT, @LegalEntityKey

	    ELSE IF @ThirdPartyTypeKey = 2
		  EXEC process.solr.pThirdPartyValuerDetail	  @Msg OUTPUT, @LegalEntityKey
	   
	    ELSE 
	    BEGIN
			 EXEC process.solr.pThirdPartyAttorneyDetail  @Msg OUTPUT, @LegalEntityKey
			 EXEC process.solr.pThirdPartyValuerDetail	 @Msg OUTPUT, @LegalEntityKey
	    END	  
	   	  

	IF @ThirdPartyKey IS NOT NULL 
		BEGIN
		  SELECT	* 
		  FROM	[2AM].solr.ThirdParty (NOLOCK) 
		  WHERE	LegalEntityKey = @LegalEntityKey 
		END
		 		
		END TRY

		BEGIN CATCH

	   
			set @Msg = 'solr.pThirdPartyExtract: ' + ISNULL(ERROR_MESSAGE(), 'Failed!')
			RAISERROR(@Msg,16,1)

			SELECT TOP 0 * INTO #Errors FROM process.template.errors
	
			DELETE FROM #Errors
			INSERT INTO #Errors (ErrorCodeKey, DateOfError, MSG, SeverityTypeKey)
			SELECT (SELECT ErrorCodeKey FROM process.errorhandling.ErrorCode (NOLOCK) WHERE Description LIKE 'Solr Extract Failure'), GETDATE(), @Msg, 1
	
			EXEC process.errorhandling.pLogErrors @Msg OUTPUT
				
		END CATCH

END
GO





	