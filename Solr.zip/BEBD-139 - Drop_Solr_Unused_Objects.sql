USE [2AM]
GO

IF EXISTS ( SELECT 1 FROM [2AM].sys.procedures WHERE Name = 'pInitiateServiceBrokerMessage')
    DROP PROCEDURE dbo.pInitiateServiceBrokerMessage

GO

USE Process
GO

IF EXISTS ( SELECT 1 FROM process.sys.procedures WHERE Name = 'pServiceBrokerQueueDetermine')
    DROP PROCEDURE solr.pServiceBrokerQueueDetermine



/*

SELECT *
FROM [2am].sys.objects
where schema_id = 53


SELECT *
FROM process.sys.objects
where schema_id = 30

*/

