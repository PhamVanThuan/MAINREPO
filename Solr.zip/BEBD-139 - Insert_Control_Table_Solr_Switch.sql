USE [2am]
GO


/*
		Author		:	VirekR
		CreateDate	:	2016/01/19
		Description	:	Inserts some records to switch Solr on or off
								ON = 1
								OFF = 0		

*/


IF NOT EXISTS (
				SELECT  *
				FROM	   [2am].dbo.Control
				WHERE   ControlDescription = 'Is Solr Full Import Enabled'
			   )
BEGIN
	INSERT INTO [2am].dbo.Control(ControlDescription,ControlNumeric,ControlGroupKey)
	SELECT 	'Is Solr Full Import Enabled', 1, 3
END
GO

IF NOT EXISTS (
				SELECT  *
				FROM	   [2am].dbo.Control
				WHERE   ControlDescription = 'Is Solr Incremental Update Enabled'
			   )
BEGIN
	INSERT INTO [2am].dbo.Control(ControlDescription,ControlNumeric,ControlGroupKey)
	SELECT 	'Is Solr Incremental Update Enabled', 1, 3
END
GO

--  SELECT * FROM [2am].dbo.Control WHERE ControlDescription LIKE '%Solr%'



